@echo off
setlocal
echo Generating Secure Lego Bridge Certificates...

:: Manually set the config path to the local folder
set "OPENSSL_CONF=%~dp0conf\openssl.cnf"

:: If openssl.cnf doesn't exist in your NGINX/conf folder, create an empty one first
if not exist "conf\openssl.cnf" type nul > "conf\openssl.cnf"

openssl req -x509 -sha256 -nodes -days 365 -newkey rsa:2048 -keyout conf/cert.key -out conf/cert.crt -subj "/CN=localhost"

echo.
echo Done! Please restart NGINX.
pause
